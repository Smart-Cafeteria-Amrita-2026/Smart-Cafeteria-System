import { test, expect } from '@playwright/test';

test.describe('Landing Page', () => {
    test.beforeEach(async ({ page }) => {
        await page.goto('/');
    });

    test('should display the hero section with title', async ({ page }) => {
        // The hero should contain the main title text
        const heroTitle = page.locator('h1');
        await expect(heroTitle).toBeVisible();
        await expect(heroTitle).toContainText('Smart Cafeteria');
        await expect(heroTitle).toContainText('Management System');
    });

    test('should display the Explore Menu CTA button', async ({ page }) => {
        const ctaButton = page.locator('a', { hasText: 'Explore Menu' });
        await expect(ctaButton).toBeVisible();
        await expect(ctaButton).toHaveAttribute('href', '#meal-categories');
    });

    test('should display Login and Register links in navbar when not logged in', async ({ page }) => {
        const loginLink = page.locator('nav a[href="/login"]');
        const registerLink = page.locator('nav a[href="/register"]');

        await expect(loginLink).toBeVisible();
        await expect(loginLink).toContainText('Login');

        await expect(registerLink).toBeVisible();
        await expect(registerLink).toContainText('Register');
    });

    test('should have the meal categories section', async ({ page }) => {
        const mealSection = page.locator('#meal-categories');
        // If the backend is running and returns data, the section will have cards
        // If not, it may show a loading skeleton or "no meals" message — either is OK
        // We just check the section element exists in the DOM
        await expect(mealSection.or(page.locator('text=Explore'))).toBeVisible();
    });

    test('should have correct page metadata', async ({ page }) => {
        // The page should have a title set
        const title = await page.title();
        expect(title).toBeTruthy();
    });

    test('should display the navbar brand/logo linking to home', async ({ page }) => {
        const brand = page.locator('nav a[href="/"]');
        await expect(brand).toBeVisible();
        await expect(brand).toContainText('SC');
    });

    test('should have the info section on the landing page', async ({ page }) => {
        // The LandingInfo component should render below the meal categories
        // Check for any content that appears after the meal section
        const pageContent = page.locator('main');
        await expect(pageContent).toBeVisible();
    });
});
