import { test, expect } from '@playwright/test';

test.describe('Staff Dashboard', () => {
    test('staff page exists at /staff route', async ({ page }) => {
        await page.goto('/staff');
        await page.waitForLoadState('networkidle');

        // Staff page should either load (if authenticated as staff) or redirect/block
        const url = page.url();
        const pageContent = page.locator('main');
        await expect(pageContent).toBeVisible();

        // The URL should either stay at /staff or redirect to login/home
        expect(
            url.includes('/staff') || url.includes('/login') || url === 'http://localhost:3000/'
        ).toBeTruthy();
    });

    test('staff page redirects non-staff users', async ({ page }) => {
        // Unauthenticated access to staff page
        await page.goto('/staff');
        await page.waitForLoadState('networkidle');

        // Since we're not logged in, we should not see the staff dashboard
        // The page should either redirect or show loading/landing
        const url = page.url();
        const hasStaffContent = await page.locator('text=Staff Dashboard').isVisible().catch(() => false);
        const hasStaffTokens = await page.locator('text=Token').isVisible().catch(() => false);

        // Without auth, staff dashboard content should not be accessible
        // (page may still be at /staff but show landing/redirect)
        expect(url.includes('/staff') || url.includes('/login') || url === 'http://localhost:3000/').toBeTruthy();
    });
});

test.describe('Protected Pages - Access Control', () => {
    test('profile page without auth shows appropriate response', async ({ page }) => {
        // Clear auth state
        await page.goto('/');
        await page.evaluate(() => {
            localStorage.removeItem('auth-store');
        });

        await page.goto('/profile');
        await page.waitForLoadState('networkidle');

        // Should show login prompt, redirect to login, or show profile page (with no data)
        const pageContent = page.locator('main');
        await expect(pageContent).toBeVisible();
    });

    test('transaction history page without auth', async ({ page }) => {
        await page.goto('/');
        await page.evaluate(() => {
            localStorage.removeItem('auth-store');
        });

        await page.goto('/transaction-history');
        await page.waitForLoadState('networkidle');

        const pageContent = page.locator('main');
        await expect(pageContent).toBeVisible();
    });

    test('wallet page without auth', async ({ page }) => {
        await page.goto('/');
        await page.evaluate(() => {
            localStorage.removeItem('auth-store');
        });

        await page.goto('/wallet');
        await page.waitForLoadState('networkidle');

        const pageContent = page.locator('main');
        await expect(pageContent).toBeVisible();
    });

    test('my-bookings page without auth', async ({ page }) => {
        await page.goto('/');
        await page.evaluate(() => {
            localStorage.removeItem('auth-store');
        });

        await page.goto('/my-bookings');
        await page.waitForLoadState('networkidle');

        const pageContent = page.locator('main');
        await expect(pageContent).toBeVisible();
    });
});

test.describe('Checkout & Payment Pages', () => {
    test('checkout page exists', async ({ page }) => {
        await page.goto('/checkout');
        await page.waitForLoadState('networkidle');

        // Checkout page should load and show some content
        const pageContent = page.locator('main');
        await expect(pageContent).toBeVisible();
    });

    test('payment page exists', async ({ page }) => {
        await page.goto('/payment');
        await page.waitForLoadState('networkidle');

        const pageContent = page.locator('main');
        await expect(pageContent).toBeVisible();
    });
});
