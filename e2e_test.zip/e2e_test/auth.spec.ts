import { test, expect } from '@playwright/test';

test.describe('Authentication - Login Page', () => {
    test.beforeEach(async ({ page }) => {
        await page.goto('/login');
    });

    test('should load the login page with correct heading', async ({ page }) => {
        await expect(page.locator('text=Sign in')).toBeVisible();
        await expect(page.locator('text=Enter your credentials to continue')).toBeVisible();
    });

    test('should display email and password input fields', async ({ page }) => {
        const emailInput = page.locator('#email');
        const passwordInput = page.locator('#password');

        await expect(emailInput).toBeVisible();
        await expect(emailInput).toHaveAttribute('type', 'email');
        await expect(emailInput).toHaveAttribute('placeholder', 'you@example.com');

        await expect(passwordInput).toBeVisible();
        await expect(passwordInput).toHaveAttribute('type', 'password');
    });

    test('should display the Login submit button', async ({ page }) => {
        const submitButton = page.locator('button[type="submit"]');
        await expect(submitButton).toBeVisible();
        await expect(submitButton).toContainText('Login');
    });

    test('should show email validation warning for invalid email', async ({ page }) => {
        const emailInput = page.locator('#email');
        await emailInput.fill('invalidemail');
        // Trigger validation by clicking elsewhere
        await page.locator('#password').click();

        const warning = page.locator('text=Enter a valid email address');
        await expect(warning).toBeVisible();
    });

    test('should show password required warning when email is filled but password is empty', async ({ page }) => {
        const emailInput = page.locator('#email');
        await emailInput.fill('test@example.com');
        // Wait for validation to trigger
        await page.waitForTimeout(300);

        const warning = page.locator('text=Password is required');
        await expect(warning).toBeVisible();
    });

    test('should have a Forgot password link', async ({ page }) => {
        const forgotLink = page.locator('a[href="/forgot-password"]');
        await expect(forgotLink).toBeVisible();
        await expect(forgotLink).toContainText('Forgot password?');
    });

    test('should have a Sign up link that navigates to register page', async ({ page }) => {
        const signUpLink = page.locator('a[href="/register"]');
        await expect(signUpLink).toBeVisible();
        await expect(signUpLink).toContainText('Sign up');

        await signUpLink.click();
        await expect(page).toHaveURL(/\/register/);
    });

    test('should submit login form and intercept API call', async ({ page }) => {
        // Intercept the login API call
        const loginPromise = page.waitForRequest((request) =>
            request.url().includes('/api/auth/signIn') && request.method() === 'POST'
        );

        await page.locator('#email').fill('testuser@example.com');
        await page.locator('#password').fill('TestPassword123!');
        await page.locator('button[type="submit"]').click();

        // Verify the button shows loading state
        await expect(page.locator('button[type="submit"]')).toContainText(/Signing in|Login/);
    });

    test('should disable submit button while loading', async ({ page }) => {
        // Mock a slow API response
        await page.route('**/api/auth/signIn', async (route) => {
            await new Promise((resolve) => setTimeout(resolve, 2000));
            await route.fulfill({
                status: 200,
                contentType: 'application/json',
                body: JSON.stringify({ message: 'Success', data: { token: 'test-token' } }),
            });
        });

        await page.locator('#email').fill('test@example.com');
        await page.locator('#password').fill('password123');
        await page.locator('button[type="submit"]').click();

        // Button should show loading text and be disabled
        const submitButton = page.locator('button[type="submit"]');
        await expect(submitButton).toContainText('Signing in...');
        await expect(submitButton).toBeDisabled();
    });
});

test.describe('Authentication - Register Page', () => {
    test.beforeEach(async ({ page }) => {
        await page.goto('/register');
    });

    test('should load the register page', async ({ page }) => {
        // Verify the page loaded (RegisterForm or RegisterFormSkeleton should be present)
        await expect(page.locator('form').or(page.locator('text=Sign up').first())).toBeVisible();
    });

    test('should display registration form fields', async ({ page }) => {
        // Wait for the form to fully render
        await page.waitForLoadState('networkidle');

        // Check that the page has a form or 'Sign up' heading visible
        const form = page.locator('form');
        const hasForm = await form.isVisible().catch(() => false);

        if (hasForm) {
            // Form should have email input at minimum
            const emailInput = page.locator('input[type="email"], input[name="email"]');
            await expect(emailInput.first()).toBeVisible();
        }
    });

    test('should have a link to sign in page', async ({ page }) => {
        // There should be a link that navigates to login
        const signInLink = page.locator('a[href="/login"]');
        if (await signInLink.isVisible()) {
            await expect(signInLink).toBeVisible();
            await signInLink.click();
            await expect(page).toHaveURL(/\/login/);
        }
    });
});

test.describe('Authentication - Forgot Password Page', () => {
    test.beforeEach(async ({ page }) => {
        await page.goto('/forgot-password');
    });

    test('should load the forgot password page', async ({ page }) => {
        await page.waitForLoadState('networkidle');
        // The page should show a form with an email field or relevant heading
        const pageContent = page.locator('main');
        await expect(pageContent).toBeVisible();
    });

    test('should be accessible from login page', async ({ page }) => {
        await page.goto('/login');
        const forgotLink = page.locator('a[href="/forgot-password"]');
        await forgotLink.click();
        await expect(page).toHaveURL(/\/forgot-password/);
    });
});

test.describe('Authentication Flow - Cross-page Navigation', () => {
    test('login → register → login roundtrip', async ({ page }) => {
        // Start at login
        await page.goto('/login');
        await expect(page.locator('text=Sign in')).toBeVisible();

        // Go to register
        const signUpLink = page.locator('a[href="/register"]');
        await signUpLink.click();
        await expect(page).toHaveURL(/\/register/);

        // Go back to login
        await page.waitForLoadState('networkidle');
        const signInLink = page.locator('a[href="/login"]');
        if (await signInLink.isVisible()) {
            await signInLink.click();
            await expect(page).toHaveURL(/\/login/);
        }
    });

    test('login page → forgot password navigation', async ({ page }) => {
        await page.goto('/login');
        const forgotLink = page.locator('a[href="/forgot-password"]');
        await forgotLink.click();
        await expect(page).toHaveURL(/\/forgot-password/);
    });
});
