import { test, expect } from '@playwright/test';

test.describe('Booking Flow - Slot Selection', () => {
    test('slots page loads with correct heading for breakfast', async ({ page }) => {
        await page.goto('/slots?type=breakfast');
        await page.waitForLoadState('networkidle');

        const heading = page.locator('h1');
        await expect(heading).toBeVisible();
        await expect(heading).toContainText(/breakfast/i);
    });

    test('slots page loads with correct heading for lunch', async ({ page }) => {
        await page.goto('/slots?type=lunch');
        await page.waitForLoadState('networkidle');

        const heading = page.locator('h1');
        await expect(heading).toBeVisible();
        await expect(heading).toContainText(/lunch/i);
    });

    test('slots page loads with correct heading for dinner', async ({ page }) => {
        await page.goto('/slots?type=dinner');
        await page.waitForLoadState('networkidle');

        const heading = page.locator('h1');
        await expect(heading).toBeVisible();
        await expect(heading).toContainText(/dinner/i);
    });

    test('slots page loads with correct heading for snack', async ({ page }) => {
        await page.goto('/slots?type=snack');
        await page.waitForLoadState('networkidle');

        const heading = page.locator('h1');
        await expect(heading).toBeVisible();
        await expect(heading).toContainText(/snack/i);
    });

    test('slots page has a back button', async ({ page }) => {
        await page.goto('/slots?type=breakfast');
        await page.waitForLoadState('networkidle');

        // The back arrow button should be visible
        const backButton = page.locator('button').filter({ has: page.locator('svg') }).first();
        await expect(backButton).toBeVisible();
    });

    test('slots page shows subtitle text', async ({ page }) => {
        await page.goto('/slots?type=breakfast');
        await page.waitForLoadState('networkidle');

        const subtitle = page.locator('text=Pick a slot and member count');
        await expect(subtitle).toBeVisible();
    });
});

test.describe('Booking Flow - Menu Page Guard', () => {
    test('menu page without slot selection shows fallback', async ({ page }) => {
        // Clear any previous booking state
        await page.goto('/');
        await page.evaluate(() => {
            localStorage.removeItem('booking-store');
            sessionStorage.removeItem('booking_edit_context');
        });

        await page.goto('/menu');
        await page.waitForLoadState('networkidle');

        // Should show "Please select a time slot first" message
        const message = page.locator('text=Please select a time slot first');
        const goBackButton = page.locator('text=Go back to Slots');
        const menuHeading = page.locator('h1', { hasText: /Menu/ });

        // Either shows guard message or the menu (if store was hydrated with data)
        const hasGuard = await message.isVisible().catch(() => false);
        const hasMenu = await menuHeading.isVisible().catch(() => false);

        expect(hasGuard || hasMenu).toBeTruthy();

        if (hasGuard) {
            await expect(goBackButton).toBeVisible();
        }
    });

    test('menu guard "Go back to Slots" button navigates correctly', async ({ page }) => {
        // Clear booking state
        await page.goto('/');
        await page.evaluate(() => {
            localStorage.removeItem('booking-store');
            sessionStorage.removeItem('booking_edit_context');
        });

        await page.goto('/menu');
        await page.waitForLoadState('networkidle');

        const goBackButton = page.locator('text=Go back to Slots');
        const hasGuard = await goBackButton.isVisible().catch(() => false);

        if (hasGuard) {
            await goBackButton.click();
            await expect(page).toHaveURL(/\/slots/);
        }
    });
});

test.describe('Booking Flow - Cart Page', () => {
    test('cart page loads with header', async ({ page }) => {
        await page.goto('/cart');
        await page.waitForLoadState('networkidle');

        await expect(page.locator('h1', { hasText: 'Your Cart' })).toBeVisible();
    });

    test('cart page has a back button', async ({ page }) => {
        await page.goto('/cart');
        await page.waitForLoadState('networkidle');

        const backButton = page.locator('button').filter({ has: page.locator('svg') }).first();
        await expect(backButton).toBeVisible();
    });

    test('empty cart shows appropriate state', async ({ page }) => {
        // Clear cart state
        await page.goto('/');
        await page.evaluate(() => {
            localStorage.removeItem('cart-store');
        });

        await page.goto('/cart');
        await page.waitForLoadState('networkidle');

        // The cart page should show either empty state or the cart list
        const cartContent = page.locator('main');
        await expect(cartContent).toBeVisible();
    });
});

test.describe('Booking Flow - Landing to Slots Navigation', () => {
    test('meal category card links to slots page with correct type', async ({ page }) => {
        await page.goto('/');
        await page.waitForLoadState('networkidle');

        // Find any meal category card link
        const mealCards = page.locator('#meal-categories a');
        const cardCount = await mealCards.count();

        if (cardCount > 0) {
            const firstCard = mealCards.first();
            const href = await firstCard.getAttribute('href');

            // Each card should link to /slots?type=<mealType>
            expect(href).toContain('/slots');

            await firstCard.click();
            await expect(page).toHaveURL(/\/slots/);
        }
    });
});
