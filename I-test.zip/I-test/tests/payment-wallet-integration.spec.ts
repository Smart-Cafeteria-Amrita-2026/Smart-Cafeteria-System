import { test, expect } from "@playwright/test";

const API = "http://localhost:3001";

test.describe("Wallet: Frontend ↔ Backend Integration", () => {
  test("Wallet page requires authentication", async ({ page }) => {
    await page.goto("/wallet");
    await page.waitForTimeout(3000);
    if (page.url().includes("/login")) await expect(page.getByText("Sign in")).toBeVisible();
    else expect((await page.getByText(/wallet|balance|top.up|recharge/i).count()) > 0).toBe(true);
  });

  test("Transaction history page requires authentication", async ({ page }) => {
    await page.goto("/transaction-history");
    await page.waitForTimeout(3000);
    if (page.url().includes("/login")) await expect(page.getByText("Sign in")).toBeVisible();
    else expect((await page.getByText(/transaction|history|payment/i).count()) > 0).toBe(true);
  });

  test("Payment success page handles direct access", async ({ page }) => {
    expect((await page.goto("/payment/success"))?.status()).toBeLessThan(500);
  });
});

test.describe("Payment: Backend API Auth Integration", () => {
  test("GET /api/payments/personal-wallet/balance requires auth", async ({ request }) => {
    expect((await request.get(`${API}/api/payments/personal-wallet/balance`)).status()).toBe(401);
  });
  test("GET /api/payments/personal-wallet/transactions requires auth", async ({ request }) => {
    expect((await request.get(`${API}/api/payments/personal-wallet/transactions`)).status()).toBe(401);
  });
  test("POST /api/payments/personal-wallet/create-session requires auth", async ({ request }) => {
    expect((await request.post(`${API}/api/payments/personal-wallet/create-session`, { data: {} })).status()).toBe(401);
  });
  test("POST /api/payments/stripe/create-intent requires auth", async ({ request }) => {
    expect((await request.post(`${API}/api/payments/stripe/create-intent`, { data: {} })).status()).toBe(401);
  });
  test("POST /api/payments/stripe/confirm requires auth", async ({ request }) => {
    expect((await request.post(`${API}/api/payments/stripe/confirm`, { data: {} })).status()).toBe(401);
  });
  test("POST /api/payments/settle/:bookingId requires auth", async ({ request }) => {
    expect((await request.post(`${API}/api/payments/settle/fake-booking`, { data: {} })).status()).toBe(401);
  });
  test("POST /api/payments/wallet/contribute requires auth", async ({ request }) => {
    expect((await request.post(`${API}/api/payments/wallet/contribute`, { data: {} })).status()).toBe(401);
  });
  test("GET /api/payments/window/:bookingId requires auth", async ({ request }) => {
    expect((await request.get(`${API}/api/payments/window/fake-booking`)).status()).toBe(401);
  });
});

test.describe("Payment: Public Endpoints Integration", () => {
  test("GET /api/payments/walk-in/available returns data", async ({ request }) => {
    const res = await request.get(`${API}/api/payments/walk-in/available`);
    expect(res.status()).toBe(200);
    expect(await res.json()).toHaveProperty("success");
  });
});
