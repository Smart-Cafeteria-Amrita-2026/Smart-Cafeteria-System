import { test, expect } from "@playwright/test";

const API = "http://localhost:3001";

test.describe("Staff Dashboard: Frontend Auth Guard Integration", () => {
  for (const sp of [
    { path: "/staff", name: "Dashboard" },
    { path: "/staff/forecast", name: "Forecast" },
    { path: "/staff/inventory", name: "Inventory" },
    { path: "/staff/slots", name: "Slot Management" },
  ]) {
    test(`${sp.name} page (${sp.path}) requires staff authentication`, async ({ page }) => {
      await page.goto(sp.path);
      await page.waitForTimeout(3000);
      const url = page.url();
      if (!url.includes(sp.path)) {
        expect(url.includes("/login") || url === "http://localhost:3000/").toBe(true);
      } else {
        expect((await page.goto(sp.path))?.status()).toBeLessThan(500);
      }
    });
  }
});

test.describe("Staff: No-Show & Walk-In API Integration", () => {
  test("POST /api/payments/no-show/process/:slotId requires staff auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.post(`${API}/api/payments/no-show/process/fake-slot`, { data: {} })).status());
  });
  test("POST /api/payments/walk-in/assign requires staff auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.post(`${API}/api/payments/walk-in/assign`, { data: {} })).status());
  });
});

test.describe("Staff: Leftover Food API Integration", () => {
  test("GET /api/payments/leftover/:slotId requires staff auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.get(`${API}/api/payments/leftover/fake-slot`)).status());
  });
  test("POST /api/payments/leftover/transfer requires staff auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.post(`${API}/api/payments/leftover/transfer`, { data: {} })).status());
  });
});

test.describe("Staff: Reports API Integration", () => {
  test("GET /api/payments/reports/no-show requires staff auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.get(`${API}/api/payments/reports/no-show`)).status());
  });
  test("GET /api/payments/reports/unused-slots requires staff auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.get(`${API}/api/payments/reports/unused-slots`)).status());
  });
  test("GET /api/payments/reports/unused-meals requires staff auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.get(`${API}/api/payments/reports/unused-meals`)).status());
  });
});

test.describe("Staff: Meal Slot Creation & Admin API Integration", () => {
  test("POST /api/meal-slots requires auth", async ({ request }) => {
    expect((await request.post(`${API}/api/meal-slots`, { data: {} })).status()).toBe(401);
  });
  test("POST /api/meal-slots/menu-mapping requires auth", async ({ request }) => {
    expect((await request.post(`${API}/api/meal-slots/menu-mapping`, { data: {} })).status()).toBe(401);
  });
  test("POST /api/payments/window/:bookingId/extend requires admin auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.post(`${API}/api/payments/window/fake-booking/extend`, { data: {} })).status());
  });
  test("POST /api/payments/process-expired requires admin auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.post(`${API}/api/payments/process-expired`, { data: {} })).status());
  });
});
