import { test, expect } from "@playwright/test";

const API = "http://localhost:3001";

test.describe("Slots: Frontend ↔ Backend Integration", () => {
  test("Slots page fetches data from backend API", async ({ page }) => {
    const [apiResponse] = await Promise.all([
      page.waitForResponse((res) => res.url().includes("/api/bookings/slots"), { timeout: 15000 }).catch(() => null),
      page.goto("/slots"),
    ]);
    if (apiResponse) {
      expect(apiResponse.status()).toBe(200);
      const body = await apiResponse.json();
      expect(body).toHaveProperty("success");
    }
    await page.waitForTimeout(3000);
    expect((await page.getByText(/slot|meal|available|no slot/i).count()) > 0).toBe(true);
  });

  test("Slot recommendations API integrates with frontend", async ({ page }) => {
    await page.goto("/slots");
    const [recResponse] = await Promise.all([
      page.waitForResponse((res) => res.url().includes("/api/bookings/slots/recommendations"), { timeout: 10000 }).catch(() => null),
      page.waitForTimeout(5000),
    ]);
    if (recResponse) expect(recResponse.status()).toBe(200);
  });
});

test.describe("Menu: Frontend ↔ Backend Integration", () => {
  test("Menu page fetches menu items from backend", async ({ page }) => {
    const [apiResponse] = await Promise.all([
      page.waitForResponse((res) => res.url().includes("/api/bookings/slots") || res.url().includes("/api/meal-slots/menu-items"), { timeout: 15000 }).catch(() => null),
      page.goto("/menu"),
    ]);
    if (apiResponse) expect(apiResponse.status()).toBe(200);
    await page.waitForTimeout(3000);
    expect((await page.getByText(/menu|food|item|category|breakfast|lunch|dinner/i).count()) > 0).toBe(true);
  });

  test("Menu category pages load with filtered data", async ({ page }) => {
    for (const cat of ["breakfast", "lunch", "dinner", "snacks", "beverages"]) {
      const response = await page.goto(`/menu/${cat}`);
      expect(response?.status()).toBeLessThan(500);
      await page.waitForTimeout(1000);
    }
  });

  test("Menu search sends query to backend API", async ({ page }) => {
    await page.goto("/menu");
    await page.waitForTimeout(2000);
    const searchInput = page.locator('input[type="search"], input[placeholder*="earch" i]').first();
    if (await searchInput.isVisible()) {
      const [apiReq] = await Promise.all([
        page.waitForRequest((req) => req.url().includes("/api/bookings/menu/search"), { timeout: 5000 }).catch(() => null),
        searchInput.fill("rice"),
      ]);
      if (apiReq) expect(apiReq.method()).toBe("POST");
    }
  });
});

test.describe("Slots & Menu: Backend API Direct Integration", () => {
  test("GET /api/bookings/slots returns valid data", async ({ request }) => {
    const res = await request.get(`${API}/api/bookings/slots`);
    expect(res.status()).toBe(200);
    const body = await res.json();
    expect(body).toHaveProperty("success");
    if (body.success && body.data) expect(Array.isArray(body.data)).toBe(true);
  });
  test("GET /api/meal-slots/menu-items returns items", async ({ request }) => {
    const res = await request.get(`${API}/api/meal-slots/menu-items`);
    expect(res.status()).toBe(200);
    expect(await res.json()).toHaveProperty("success");
  });
  test("POST /api/bookings/menu/search with query returns results", async ({ request }) => {
    const res = await request.post(`${API}/api/bookings/menu/search`, { data: { query: "rice" } });
    expect([200, 400]).toContain(res.status());
  });
  test("GET /api/bookings/demand-analysis returns data", async ({ request }) => {
    const res = await request.get(`${API}/api/bookings/demand-analysis`);
    expect([200, 400]).toContain(res.status());
  });
});
