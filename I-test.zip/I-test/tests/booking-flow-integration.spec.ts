import { test, expect } from "@playwright/test";

const API = "http://localhost:3001";

test.describe("Booking Pipeline: Unauthenticated Guard Integration", () => {
  test("Cart page redirects or shows empty state for unauthenticated users", async ({ page }) => {
    await page.goto("/cart");
    await page.waitForTimeout(3000);
    const url = page.url();
    if (url.includes("/login")) {
      await expect(page.getByText("Sign in")).toBeVisible();
    } else {
      expect(await page.textContent("body")).toBeTruthy();
    }
  });

  test("Checkout page redirects unauthenticated users", async ({ page }) => {
    await page.goto("/checkout");
    await page.waitForTimeout(3000);
    const response = await page.goto("/checkout");
    expect(response?.status()).toBeLessThan(500);
  });

  test("My-Bookings page requires authentication", async ({ page }) => {
    await page.goto("/my-bookings");
    await page.waitForTimeout(3000);
    if (page.url().includes("/login")) {
      await expect(page.getByText("Sign in")).toBeVisible();
    }
  });
});

test.describe("Booking: Backend API Integration", () => {
  test("POST /api/bookings without auth returns 401", async ({ request }) => {
    expect((await request.post(`${API}/api/bookings`, { data: { slotId: "test", items: [] } })).status()).toBe(401);
  });
  test("GET /api/bookings/my-bookings without auth returns 401", async ({ request }) => {
    expect((await request.get(`${API}/api/bookings/my-bookings`)).status()).toBe(401);
  });
  test("GET /api/bookings/payments without auth returns 401", async ({ request }) => {
    expect((await request.get(`${API}/api/bookings/payments`)).status()).toBe(401);
  });
  test("PUT /api/bookings/:id without auth returns 401", async ({ request }) => {
    expect((await request.put(`${API}/api/bookings/fake-id`, { data: {} })).status()).toBe(401);
  });
  test("DELETE /api/bookings/:id without auth returns 401", async ({ request }) => {
    expect((await request.delete(`${API}/api/bookings/fake-id`)).status()).toBe(401);
  });
  test("GET /api/bookings/users/search without auth returns 401", async ({ request }) => {
    expect((await request.get(`${API}/api/bookings/users/search?q=test`)).status()).toBe(401);
  });
});

test.describe("Booking Confirmation & Update Pages", () => {
  test("Booking confirmation page handles direct access", async ({ page }) => {
    expect((await page.goto("/booking-confirmation"))?.status()).toBeLessThan(500);
  });
  test("Booking update confirmation page handles direct access", async ({ page }) => {
    expect((await page.goto("/booking-update-confirmation"))?.status()).toBeLessThan(500);
  });
  test("Individual booking detail with invalid ID does not crash", async ({ page }) => {
    expect((await page.goto("/my-bookings/invalid-booking-id"))?.status()).toBeLessThan(500);
  });
});
