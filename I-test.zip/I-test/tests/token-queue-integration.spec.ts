import { test, expect } from "@playwright/test";

const API = "http://localhost:3001";

test.describe("Token Queue: Public API Integration", () => {
  test("GET /api/tokens/queue/status returns queue data", async ({ request }) => {
    const res = await request.get(`${API}/api/tokens/queue/status`);
    expect(res.status()).toBe(200);
    expect(await res.json()).toHaveProperty("success");
  });
  test("GET /api/tokens/counters returns counter data", async ({ request }) => {
    const res = await request.get(`${API}/api/tokens/counters`);
    expect(res.status()).toBe(200);
    expect(await res.json()).toHaveProperty("success");
  });
  test("SSE endpoint /api/tokens/queue/live is accessible", async ({ request }) => {
    const res = await request.get(`${API}/api/tokens/queue/live`, { headers: { Accept: "text/event-stream" }, timeout: 5000 }).catch(() => null);
    if (res) expect(res.status()).toBe(200);
  });
});

test.describe("Token Queue: Auth-Protected API Integration", () => {
  test("POST /api/tokens/generate requires auth", async ({ request }) => {
    expect((await request.post(`${API}/api/tokens/generate`, { data: {} })).status()).toBe(401);
  });
  test("GET /api/tokens/my-tokens requires auth", async ({ request }) => {
    expect((await request.get(`${API}/api/tokens/my-tokens`)).status()).toBe(401);
  });
  test("GET /api/tokens/:tokenId requires auth", async ({ request }) => {
    expect((await request.get(`${API}/api/tokens/fake-token-id`)).status()).toBe(401);
  });
  test("POST /api/tokens/:tokenId/activate requires auth", async ({ request }) => {
    expect((await request.post(`${API}/api/tokens/fake-token/activate`, { data: {} })).status()).toBe(401);
  });
  test("GET /api/tokens/booking/:ref requires auth", async ({ request }) => {
    expect((await request.get(`${API}/api/tokens/booking/fake-ref`)).status()).toBe(401);
  });
});

test.describe("Token Queue: Staff Operations API Integration", () => {
  test("POST /api/tokens/meal-slot/:slotId/activate requires staff auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.post(`${API}/api/tokens/meal-slot/fake-slot/activate`, { data: {} })).status());
  });
  test("POST /api/tokens/counters/:id/call-next requires staff auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.post(`${API}/api/tokens/counters/1/call-next`, { data: {} })).status());
  });
  test("POST /api/tokens/:tokenId/mark-served requires staff auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.post(`${API}/api/tokens/fake-token/mark-served`, { data: {} })).status());
  });
  test("POST /api/tokens/counters/:id/close requires staff auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.post(`${API}/api/tokens/counters/1/close`, { data: {} })).status());
  });
  test("POST /api/tokens/counters/:id/reopen requires staff auth", async ({ request }) => {
    expect([401, 403]).toContain((await request.post(`${API}/api/tokens/counters/1/reopen`, { data: {} })).status());
  });
});
