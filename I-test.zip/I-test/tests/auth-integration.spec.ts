import { test, expect } from "@playwright/test";

const API = "http://localhost:3001";

test.describe("Auth: Login Flow Integration (Frontend ↔ Backend)", () => {
  test("Login page renders and form submits to backend API", async ({ page }) => {
    await page.goto("/login");
    await expect(page.getByText("Sign in")).toBeVisible();
    await expect(page.locator("#email")).toBeVisible();
    await expect(page.locator("#password")).toBeVisible();

    const [apiRequest] = await Promise.all([
      page.waitForRequest((req) => req.url().includes("/api/auth/signIn"), { timeout: 10000 }).catch(() => null),
      (async () => {
        await page.locator("#email").fill("testuser@example.com");
        await page.locator("#password").fill("TestPassword1!");
        await page.getByRole("button", { name: /login/i }).click();
      })(),
    ]);

    if (apiRequest) {
      expect(apiRequest.method()).toBe("POST");
      expect(apiRequest.url()).toContain("/api/auth/signIn");
    }
    await page.waitForTimeout(3000);
  });

  test("Login with invalid credentials returns error from backend", async ({ page }) => {
    await page.goto("/login");
    await page.locator("#email").fill("nonexistent@test.com");
    await page.locator("#password").fill("WrongPassword1!");

    const [response] = await Promise.all([
      page.waitForResponse((res) => res.url().includes("/api/auth/signIn"), { timeout: 10000 }).catch(() => null),
      page.getByRole("button", { name: /login/i }).click(),
    ]);

    if (response) {
      expect([400, 401, 422]).toContain(response.status());
    }
    await page.waitForTimeout(2000);
    expect(page.url()).toContain("/login");
  });

  test("Login form client-side validation prevents invalid API calls", async ({ page }) => {
    await page.goto("/login");
    await page.locator("#email").fill("not-an-email");
    await page.locator("#password").click();
    await expect(page.getByText("Enter a valid email address")).toBeVisible();
  });
});

test.describe("Auth: Registration Flow Integration (Frontend ↔ Backend)", () => {
  test("Registration page renders all form fields", async ({ page }) => {
    await page.goto("/register");
    await expect(page.getByText("Create account")).toBeVisible();
    await expect(page.getByLabel("First Name")).toBeVisible();
    await expect(page.getByLabel("Last Name")).toBeVisible();
    await expect(page.getByLabel("College ID")).toBeVisible();
    await expect(page.getByLabel("Mobile")).toBeVisible();
    await expect(page.getByLabel("Department")).toBeVisible();
    await expect(page.getByLabel("Email")).toBeVisible();
    await expect(page.getByLabel("Password", { exact: true }).first()).toBeVisible();
    await expect(page.getByLabel("Confirm Password")).toBeVisible();
  });

  test("Registration form validates password strength before API call", async ({ page }) => {
    await page.goto("/register");
    await page.getByLabel("Password", { exact: true }).first().fill("weak");
    await expect(page.getByText("Password must be at least 8 characters")).toBeVisible();
    await expect(page.getByText("Add at least one uppercase letter")).toBeVisible();
    await expect(page.getByText("Add at least one number")).toBeVisible();
    await expect(page.getByText("Add at least one special character")).toBeVisible();
  });

  test("Registration form submits to backend API", async ({ page }) => {
    await page.goto("/register");
    await page.getByLabel("First Name").fill("Test");
    await page.getByLabel("Last Name").fill("User");
    await page.getByLabel("College ID").fill("TEST001");
    await page.getByLabel("Mobile").fill("9876543210");
    await page.getByLabel("Department").fill("Computer Science");
    await page.getByLabel("Email").fill(`testuser_${Date.now()}@example.com`);
    await page.getByLabel("Password", { exact: true }).first().fill("SecurePass1@");
    await page.getByLabel("Confirm Password").fill("SecurePass1@");

    const [apiRequest] = await Promise.all([
      page.waitForRequest((req) => req.url().includes("/api/auth/register") || req.url().includes("/api/otp"), { timeout: 10000 }).catch(() => null),
      page.getByRole("button", { name: /register/i }).click(),
    ]);
    if (apiRequest) expect(apiRequest.method()).toBe("POST");
    await page.waitForTimeout(3000);
  });
});

test.describe("Auth: Forgot Password Flow Integration", () => {
  test("Forgot password page sends request to backend", async ({ page }) => {
    await page.goto("/forgot-password");
    const emailField = page.getByLabel(/email/i).first();
    if (await emailField.isVisible()) {
      await emailField.fill("test@example.com");
      const submitBtn = page.getByRole("button", { name: /send|submit|reset/i }).first();
      if (await submitBtn.isVisible()) {
        const [apiReq] = await Promise.all([
          page.waitForRequest((r) => r.url().includes("/api/auth/forgot-password"), { timeout: 5000 }).catch(() => null),
          submitBtn.click(),
        ]);
        if (apiReq) expect(apiReq.method()).toBe("POST");
      }
    }
  });
});

test.describe("Auth: Backend API Direct Integration", () => {
  test("POST /api/auth/register validates required fields", async ({ request }) => {
    const res = await request.post(`${API}/api/auth/register`, { data: {} });
    expect([400, 422]).toContain(res.status());
  });
  test("POST /api/auth/signIn rejects invalid credentials", async ({ request }) => {
    const res = await request.post(`${API}/api/auth/signIn`, { data: { email: "fake@test.com", password: "FakePass123!" } });
    expect([400, 401, 422]).toContain(res.status());
  });
  test("GET /api/auth/profile without auth returns 401", async ({ request }) => {
    const res = await request.get(`${API}/api/auth/profile`);
    expect(res.status()).toBe(401);
  });
  test("POST /api/otp/generate validates input", async ({ request }) => {
    const res = await request.post(`${API}/api/otp/generate`, { data: {} });
    expect([400, 422]).toContain(res.status());
  });
  test("POST /api/otp/verify validates input", async ({ request }) => {
    const res = await request.post(`${API}/api/otp/verify`, { data: {} });
    expect([400, 422]).toContain(res.status());
  });
});
